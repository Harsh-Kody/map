export const environment = {
  production: true,
  webServiceEndPointURL: 'http://192.168.0.102/v0',
};
