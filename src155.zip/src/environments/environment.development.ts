export const environment = {
  webServiceEndPointURL: 'http://192.168.0.102/v0',
};
